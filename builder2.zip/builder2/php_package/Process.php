<?php
 $u = $_POST["Company"];
 $p = $_POST["Name"];
 $id = $_POST["Address"];
// require_once 'Admin.php';
 $o = new Admin();
 $r = $o->addUser($u, $p, $id);
 //header("location:index.php?t=$r");
 
?>
