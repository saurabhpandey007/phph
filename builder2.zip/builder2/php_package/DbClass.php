<?php
class Admin 
{
   function connect()
   {
     $dsn = mysql_connect("localhost","root","");
      mysql_select_db("kuldeep",$dsn);  
   }
   function addUser($u,$p,$id)
   {
     $this->connect();
     $r = mysql_query("call addUser('$u','$p','$id')");
     mysql_close(); 
     return $r;
   } 
   function checkId($u,$p)
   {
     $this->connect();
     $r = mysql_query("call checkId('$u','$p')");
     $rs = mysql_fetch_row($r);
     mysql_close(); 
     return $rs[0];
   }
   
   function changePass($u,$op,$np)
   {
     $this->connect();
     $r = mysql_query("call changePass('$u','$op','$np')");
     mysql_close(); 
     if($r==1)
         return "Password Successfully Changed.";
     else
         return "Sorry ur old password not matched.";
   }
   function delUser($u)
   {
     $this->connect();
     $r = mysql_query("call delUser('$u')");
     mysql_close(); 
     if($r==1)
         return "User Successfully Deleted.";
     else
         return "Sorry user does not exist.";
   }
   function getUsers()
   {
     $this->connect();
     $r = mysql_query("call getUsers()");
     echo "Number of row - ".mysql_num_rows($r);
     for($i=0;$i<mysql_num_rows($r);$i++)
     {
        $rs = mysql_fetch_row($r);
        echo "    <option value=$rs[0]>$rs[0]</option><br>";
     }  
     mysql_close(); 
   }
   
}

?>
